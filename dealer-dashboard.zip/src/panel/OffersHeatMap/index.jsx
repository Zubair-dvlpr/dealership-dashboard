import React from 'react';
import HeatMap from '../../components/Heatmap/HeatMap';

export const OffersHeatmap = () => {
  return <HeatMap />;
};
