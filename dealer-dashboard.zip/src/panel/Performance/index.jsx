import React from 'react';
import RoofTopPerformance from '../../components/Performance/RoofTopPerformance';

export const Performance = () => {
  return <RoofTopPerformance />;
};
